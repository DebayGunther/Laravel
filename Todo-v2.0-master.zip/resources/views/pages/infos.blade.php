@extends('../master')

@section('title')
    <h1>A propos</h1>
@endsection

@section('contenu')
<div style="text-align:center">
    <div id="debay">
        Debay Günther </br></br>



    </div>

    <div id="severijns">
        Severijns Benjamin </br></br>
    </div>

    Techniques informatiques 2015-2016</br></br>

    <a href="https://github.com/debays/Todo-v2.0.git"  target="_blank">Lien du dépot Git</a></br></br>
    <a href="https://debays@bitbucket.org/lesprosdujava/todo.git"  target="_blank">Lien du dépot BitBucket</a></br></br>



</div>

@endsection