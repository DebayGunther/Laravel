@extends('../master')

@section('title')
    <h1>Projet Todo -  Home</h1>
@endsection

@section('contenu')




    <a href="{{route('projects')}}">Aficher les listes</a> </br>



@endsection